﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterAnimator : MonoBehaviour
{
    //speed for player
    public float speed;

    private Animator anim;
    private Rigidbody2D playerRigidbody;

    private bool playerMoving;
    private Vector2 lastMove;

    void Start()
    {
        //gets the components 
        anim = GetComponent<Animator>();
        playerRigidbody = GetComponent<Rigidbody2D>();
    }

    void Update()
    {

        playerMoving = false;

        //vector x
        //gets input from Unity's InputManager 
        //To go to Unity's InputManger click on Edit -> Preferences -> Input
        if (Input.GetAxisRaw("Horizontal") > 0.5f || Input.GetAxisRaw("Horizontal") < -0.5f)
        {
            //moves the player model
            playerRigidbody.velocity = new Vector2(Input.GetAxisRaw("Horizontal") * speed, playerRigidbody.velocity.y);
            //sets the bool to true
            playerMoving = true;
            //gets the last input
            lastMove = new Vector2(Input.GetAxisRaw("Horizontal"), 0f);
        }

        //sets the inputs into the animator's parameters
        anim.SetFloat("Moving X", Input.GetAxisRaw("Horizontal"));
        anim.SetFloat("Last Move X", Input.GetAxisRaw("Horizontal"));
        anim.SetBool("isRunning", playerMoving);

        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            anim.SetTrigger("jump");
        }
    }
}
